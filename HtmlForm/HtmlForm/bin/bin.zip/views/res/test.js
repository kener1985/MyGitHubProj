function say() {

	alert("hello");
}
